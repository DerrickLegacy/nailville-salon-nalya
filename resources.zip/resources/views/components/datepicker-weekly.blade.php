<!-- Calendar container -->

<div class="dark:bg-gray-800 shadow-xs rounded-xl px-4 pt-4">
    <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100">Calendar</h2>
    <div id="weekRangePicker" class="w-full"></div>
</div>
