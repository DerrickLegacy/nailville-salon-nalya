<div class="flex justify-center">
    <img src="{{ asset('salon.png') }}" alt="{{ config('app.name') }}" class="h-16 w-auto">
</div>
