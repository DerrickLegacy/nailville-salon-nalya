<x-app-layout>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">

        <!-- Dashboard actions -->
        <div class="sm:flex sm:justify-between sm:items-center mb-8">

            <!-- Left: Title -->
            <div class="mb-4 sm:mb-0">
                <h1 class="text-2xl md:text-3xl text-gray-800 dark:text-gray-100 font-bold">Dashboard</h1>
            </div>

            <!-- Right: Actions -->
            <div class="grid grid-flow-col sm:auto-cols-max justify-start sm:justify-end gap-2">

                <!-- Filter button -->
                <x-dropdown-filter align="right" />



                <!-- Add view button -->
                <button
                    class="btn bg-gray-900 text-gray-100 hover:bg-gray-800 dark:bg-gray-100 dark:text-gray-800 dark:hover:bg-white">
                    <svg class="fill-current shrink-0 xs:hidden" width="16" height="16" viewBox="0 0 16 16">
                        <path
                            d="M15 7H9V1c0-.6-.4-1-1-1S7 .4 7 1v6H1c-.6 0-1 .4-1 1s.4 1 1 1h6v6c0 .6.4 1 1 1s1-.4 1-1V9h6c.6 0 1-.4 1-1s-.4-1-1-1z" />
                    </svg>
                    <span class="max-xs:sr-only">Add View</span>
                </button>

            </div>

        </div>

        <!-- Cards -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-0 mb-6">
            <!-- Card 1: Today Invoices -->
            <div class="bg-teal-400 text-white rounded-xl shadow p-4 flex items-center space-x-4">
                <div class="p-3 bg-teal-500 rounded-lg">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M9 12h6m-6 4h6m2 4H7a2 2 0 01-2-2V6a2 2 0 012-2h3l2 2h4l2-2h3a2 2 0 012 2v12a2 2 0 01-2 2z" />
                    </svg>
                </div>
                <div>
                    <p class="text-sm">Today Invoices</p>
                    <p class="text-lg font-semibold">+{{ $cardData['today_invoices'] }}</p>
                </div>
            </div>

            <!-- Card 2: This Month Invoices -->
            <div class="bg-pink-400 text-white rounded-xl shadow p-4 flex items-center space-x-4">
                <div class="p-3 bg-pink-500 rounded-lg">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M9 12h6m-6 4h6m2 4H7a2 2 0 01-2-2V6a2 2 0 012-2h3l2 2h4l2-2h3a2 2 0 012 2v12a2 2 0 01-2 2z" />
                    </svg>
                </div>
                <div>
                    <p class="text-sm">This Month Invoices</p>
                    <p class="text-lg font-semibold">↑{{ $cardData['month_invoices'] }}</p>
                </div>
            </div>

            <!-- Card 3: Today Sales -->
            <div class="bg-orange-400 text-white rounded-xl shadow p-4 flex items-center space-x-4">
                <div class="p-3 bg-orange-500 rounded-lg">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.5 6h13m-11-6v6m4-6v6m-8 0h16" />
                    </svg>
                </div>
                <div>
                    <p class="text-sm">Today Sales</p>
                    <p class="text-lg font-semibold">↑{{ number_format($cardData['today_sales']) }} Ugx</p>
                </div>
            </div>

            <!-- Card 4: This Month Sales -->
            <div class="bg-green-400 text-white rounded-xl shadow p-4 flex items-center space-x-4">
                <div class="p-3 bg-green-500 rounded-lg">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round"
                            d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8V4m0 16v-4" />
                    </svg>
                </div>
                <div>
                    <p class="text-sm">This Month Sales</p>
                    <p class="text-lg font-semibold">↑{{ number_format($cardData['month_sales']) }} Ugx</p>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-[4fr_1fr] gap-4">
            <div class="space-y-6">
                <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100 flex justify-start">Todays Sales Vs
                    Previous Day</h2>
                <div class="grid grid-cols-12 gap-6">
                    <x-dashboard.dashboard-card-01 :getTodaysIncomeSales="$getTodaysIncomeSales" />
                    <x-dashboard.dashboard-card-02 :getTodaysExpense="$getTodaysExpense" />
                    <x-dashboard.dashboard-card-03 :getTodaysNetIncome="$getTodaysNetIncome" />
                </div>

                <div class="space-y-0">
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100 flex justify-start">Previous 30
                        Days
                        Transactions</h2>
                    <div class="bg-white dark:bg-gray-800 shadow-xs rounded-xl p-4">
                        <div id="myfirstchart" class="w-full"
                            style="min-height: 250px; height: 400px; max-height: 60vw;">
                        </div>
                    </div>
                </div>
                <div class="space-y-6">
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100 flex justify-start">
                        Monthly Transaction Goals
                    </h2>
                    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        @foreach ($monthlyBusinessGoals as $card)
                            <div class="bg-white rounded-xl shadow p-6 flex flex-col">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <!-- Percentage -->
                                        <p class="text-{{ $card['color'] }}-500 font-bold text-lg">
                                            {{ $card['percentage'] }}%
                                        </p>

                                        <!-- Title -->
                                        <p class="text-gray-600">{{ $card['title'] }}</p>

                                        <!-- Values -->
                                        <p class="text-gray-800 font-semibold text-sm mt-1">
                                            {{ number_format($card['value']) }} Ugx /
                                            {{ number_format($card['target']) }} Ugx
                                        </p>
                                    </div>

                                    <!-- Icon -->
                                    <div class="bg-{{ $card['color'] }}-100 p-3 rounded-lg">
                                        @if ($card['icon'] === 'money')
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                class="w-6 h-6 text-{{ $card['color'] }}-500" fill="none"
                                                viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2-1.343-2-3-2zm0 6v2m0-10V4m0 16h.01" />
                                            </svg>
                                        @elseif ($card['icon'] === 'arrow-up')
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                class="w-6 h-6 text-{{ $card['color'] }}-500" fill="none"
                                                viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                                            </svg>
                                        @elseif ($card['icon'] === 'flag')
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                class="w-6 h-6 text-{{ $card['color'] }}-500" fill="none"
                                                viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M13 7l5 5-5 5M6 7l5 5-5 5" />
                                            </svg>
                                        @elseif ($card['icon'] === 'box')
                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                class="w-6 h-6 text-{{ $card['color'] }}-500" fill="none"
                                                viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M20 13V7a2 2 0 00-2-2h-6V3H8v2H4a2 2 0 00-2 2v6h2v7a2 2 0 002 2h12a2 2 0 002-2v-7h2z" />
                                            </svg>
                                        @endif
                                    </div>
                                </div>

                                <!-- Progress Bar -->
                                <div class="w-full bg-gray-200 rounded-full h-2 mt-4">
                                    <div class="bg-{{ $card['color'] }}-500 h-2 rounded-full"
                                        style="width: {{ min($card['percentage'], 100) }}%">
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>

                <div class="space-y-6">
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100 flex justify-start">
                        Most Recent Income Transactions
                    </h2>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 border">
                            <thead class="bg-gray-50">
                                <tr>
                                    {{-- <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        ID</th> --}}

                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Transaction ID</th>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Customer</th>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Amount</th>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Type</th>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Payment Method</th>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Service</th>

                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Date</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach ($topIncomeTransactions as $transaction)
                                    <tr class="hover:bg-[#a698ff]">
                                        {{-- <td class="px-4 py-2">{{ $transaction->id }}</td> --}}
                                        <td class="px-4 py-2">{{ $transaction->transaction_id }}</td>
                                        <td class="px-4 py-2">{{ $transaction->customer_name }}</td>
                                        <td class="px-4 py-2">{{ number_format($transaction->amount, 2) }}</td>
                                        <td class="px-4 py-2">{{ $transaction->transaction_type }}</td>
                                        <td class="px-4 py-2">{{ $transaction->payment_method }}</td>
                                        <td class="px-4 py-2">{{ $transaction->service_description ?? '-' }}</td>
                                        <td class="px-4 py-2">{{ $transaction->created_at->format('Y-m-d H:i') }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                </div>

                <div class="space-y-6">
                    <h2 class="text-lg font-semibold text-gray-800 dark:text-gray-100 flex justify-start">
                        Most Recent Expense Transactions
                    </h2>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 border">
                            <thead class="bg-gray-50">
                                <tr>
                                    {{-- <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        ID</th> --}}

                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Transaction ID</th>

                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Amount</th>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Type</th>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Payment Method</th>
                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Service</th>

                                    <th
                                        class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Date</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                                @foreach ($topExpenseTransactions as $transaction)
                                    <tr class="hover:bg-[#a698ff]">
                                        {{-- <td class="px-4 py-2">{{ $transaction->id }}</td> --}}
                                        <td class="px-4 py-2">{{ $transaction->transaction_id }}</td>
                                        <td class="px-4 py-2">{{ number_format($transaction->amount, 2) }}</td>
                                        <td class="px-4 py-2">{{ $transaction->transaction_type }}</td>
                                        <td class="px-4 py-2">{{ $transaction->payment_method }}</td>
                                        <td class="px-4 py-2">{{ $transaction->service_description ?? '-' }}</td>
                                        <td class="px-4 py-2">{{ $transaction->created_at->format('Y-m-d H:i') }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>

                </div>

                <div x-data="stockAlert()" class="bg-white dark:bg-gray-800 shadow-xs rounded-xl p-4 ">
                    <h3 class="text-gray-800 dark:text-gray-100 font-semibold mb-0">Monthly Expenses Vs Income
                        Transactions</h3>
                    <div id="transactions-bar-chart" class="w-full"
                        style="min-height: 200px; height: 350px; max-height: 50vw;">
                    </div>

                    <div class="flex justify-center space-x-6 mt-4  mb-4 items-center">
                        <div class="flex items-center space-x-2">
                            <span class="w-4 h-4 rounded-full bg-blue-500 block"></span>
                            <span class="text-gray-700 text-sm">Income</span>
                        </div>
                        <div class="flex items-center space-x-2">
                            <span class="w-4 h-4 rounded-full bg-red-500 block"></span>
                            <span class="text-gray-700 text-sm">Expense</span>
                        </div>
                    </div>

                </div>

            </div>
            <div class="space-y-6">
                <!-- Calendar -->
                <x-datepicker-weekly />
                <div x-data="stockAlert()" class="bg-white dark:bg-gray-800 shadow-xs rounded-xl px-4 pt-4">
                    <h3 class="text-gray-800 dark:text-gray-100 font-semibold mb-0">Top Performing Saloon Employers
                    </h3>
                    <div id="top-employers" class="w-full"
                        style="min-height: 200px; height: 350px; max-height: 50vw;">
                    </div>
                </div>
                <div x-data="stockAlert()" class="bg-white dark:bg-gray-800 shadow-xs rounded-xl px-4 pt-4">
                    <h3 class="text-gray-800 dark:text-gray-100 font-semibold mb-0">Active Vs Deactive Employers</h3>
                    <div id="employee-status-chart" class="w-full"
                        style="min-height: 200px; height: 350px; max-height: 50vw;">
                    </div>
                    <!-- Legend -->
                    <div class="flex justify-center space-x-6 mt-4  mb-4 items-center">
                        <div class="flex items-center space-x-2">
                            <span class="w-4 h-4 rounded-full bg-green-500 block"></span>
                            <span class="text-gray-700 text-sm">Active</span>
                        </div>
                        <div class="flex items-center space-x-2">
                            <span class="w-4 h-4 rounded-full bg-red-500 block"></span>
                            <span class="text-gray-700 text-sm">Deactivated</span>
                        </div>
                    </div>
                </div>

                <div x-data="stockAlert()" class="bg-white dark:bg-gray-800 shadow-xs rounded-xl p-4">
                    <h3 class="text-gray-800 dark:text-gray-100 font-semibold mb-2">Stock Alert</h3>
                    <div class="mb-2">
                        <input type="text" placeholder="Search Item"
                            class="w-full dark:text-gray-300 border-amber-200 bg-white dark:bg-gray-800 border-0 focus:ring-transparent placeholder-gray-400 dark:placeholder-gray-500 py-3 pl-10 pr-4 rounded"
                            x-model="query" />
                    </div>

                    <div class="overflow-x-auto">
                        <div class="max-h-80 overflow-y-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700 sticky top-0">
                                    <tr>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                            Service
                                        </th>
                                        <th
                                            class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                            Stock
                                        </th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                                    <template x-for="item in filteredItems()" :key="item.id">
                                        <tr>
                                            <td class="px-4 py-2">
                                                <a :href="`{{ route('stock.item.details', ['id' => '__ID__']) }}`.replace(
                                                    '__ID__', item.id)"
                                                    class="text-blue-600 dark:text-blue-400 hover:underline"
                                                    x-text="item.service_name">
                                                </a>

                                            </td>
                                            <td class="px-4 py-2" x-text="item.stock"></td>
                                        </tr>
                                    </template>

                                    <!-- Show if no items -->
                                    <tr x-show="filteredItems().length === 0">
                                        <td class="px-4 py-2 text-center text-gray-500 dark:text-gray-400"
                                            colspan="2">
                                            No items found.
                                        </td>
                                    </tr>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</x-app-layout>
<script>
    function stockAlert() {
        return {
            query: '',
            items: [],
            filteredItems() {
                return this.items.filter(i =>
                    i.service_name.toLowerCase().includes(this.query.toLowerCase()) ||
                    i.service_type.toLowerCase().includes(this.query.toLowerCase())
                );
            },
            // Fetch stock alerts from server
            fetchItems() {
                fetch('/stock-alerts')
                    .then(resp => resp.json())
                    .then(result => {
                        this.items = result; // set items from API
                    })
                    .catch(err => console.error(err));
            },
            // init() runs automatically when Alpine component is initialized
            init() {
                this.fetchItems(); // fetch data on load
            }
        }
    }
    $.ajax({
        url: "{{ route('chart.data') }}", // Laravel route returning JSON
        method: "GET",
        dataType: "json",
        success: function(data) {
            var hideYAxis = window.innerWidth < 640;

            new Morris.Area({
                element: 'myfirstchart',
                data: data,
                xkey: 'y',
                ykeys: ['value'],
                labels: ['Income'],
                pointStrokeColors: ['#00B5B8', '#FA8E57', '#F25E75'],
                smooth: true,
                gridLineColor: '#E4E7ED',
                fillOpacity: 0.9,
                behaveLikeLine: true,
                lineColors: ['#8470FF', '#7965C1'],
                parseTime: true,
                resize: true,
                axes: !hideYAxis // disables both axes if false
            });

            // Optionally, you can hide only y-axis labels using CSS:
            if (hideYAxis) {
                $('#myfirstchart .morris-axis-label').css('display', 'none');
            }
        },
        error: function(xhr, status, error) {}
    });

    $.ajax({
        url: "{{ route('chart.income.expenses') }}", // Laravel route returning JSON
        method: "GET",
        dataType: "json",
        success: function(data) {
            new Morris.Bar({
                element: 'transactions-bar-chart',
                data: data,
                xkey: 'month',
                ykeys: ['Income', 'Expense'],
                labels: ['Income', 'Expense'],
                barColors: ['#3490dc', '#e3342f'], // blue for income, red for expense
                hideHover: 'auto',
                resize: true
            });

        },
        error: function(xhr, status, error) {
            console.error("Error loading chart data:", error);
        }
    });


    $.ajax({
        url: "{{ route('employees.status.chart') }}",
        method: "GET",
        dataType: "json",
        success: function(data) {
            new Morris.Bar({
                element: 'employee-status-chart',
                data: data,
                xkey: 'status',
                ykeys: ['count'],
                labels: ['Employees'],
                barColors: function(row, series, type) {
                    return row.label === 'Active' ? '#10b981' : '#ef4444';
                },
                hideHover: 'auto',
                resize: true,
                horizontal: true, // horizontal bars
                gridTextColor: '#6b7280',
                gridLineColor: '#e5e7eb',
                barGap: 6,
                barSizeRatio: 0.6,
                fillOpacity: 0.8,
                hoverCallback: function(index, options, content, row) {
                    return `<strong>${row.status}</strong>: ${row.count} employees`;
                }
            });
        },
        error: function(xhr, status, error) {
            console.error("Error loading chart data:", error);
        }
    });

    $.ajax({
        url: "{{ route('chart.top.employers') }}", // Laravel route returning JSON
        method: "GET",
        dataType: "json",
        success: function(data) {
            // console.log(data.length)
            // $('employerCount').text(data.length)
            new Morris.Donut({
                element: 'top-employers',
                data: data
            });

        },
        error: function(xhr, status, error) {
            console.error("Error loading chart data:", error);
        }
    });




    // fetch("{{ route('chart.data') }}") // this hits ReportController@incomeChartData
    //     .then(response => response.json())
    //     .then(data => {
    //         new Morris.Area({
    //             element: 'myfirstchart',
    //             data: data, // 🔥 now coming from DB instead of static
    //             xkey: 'y',
    //             ykeys: ['value'],
    //             labels: ['Income'],
    //             pointStrokeColors: ['#00B5B8', '#FA8E57', '#F25E75'],
    //             smooth: true,
    //             gridLineColor: '#E4E7ED',
    //             fillOpacity: 0.9, // makes the fill bold
    //             behaveLikeLine: true, // keeps line chart look but with area fill
    //             lineColors: ['#B13BFF', '#7965C1'],
    //             parseTime: true, // important since y = date
    //             resize: true
    //         });
    //     });
</script>
